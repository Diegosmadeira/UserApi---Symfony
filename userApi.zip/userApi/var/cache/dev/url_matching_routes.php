<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/users' => [
            [['_route' => 'user_index', '_controller' => 'App\\Controller\\UserController::index'], null, ['GET' => 0], null, true, false, null],
            [['_route' => 'user_create', '_controller' => 'App\\Controller\\UserController::create'], null, ['POST' => 0], null, true, false, null],
        ],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/users/([^/]++)(?'
                    .'|(*:25)'
                .')'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:61)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        25 => [
            [['_route' => 'user_show', '_controller' => 'App\\Controller\\UserController::show'], ['Id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'user_update', '_controller' => 'App\\Controller\\UserController::update'], ['Id'], ['PUT' => 0, 'PATCH' => 1], null, false, true, null],
            [['_route' => 'user_delete', '_controller' => 'App\\Controller\\UserController::delete'], ['Id'], ['DELETE' => 0], null, false, true, null],
        ],
        61 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
