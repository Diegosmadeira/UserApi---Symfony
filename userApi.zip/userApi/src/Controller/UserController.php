<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\User;

#[Route('/users', name: 'user_')]

class UserController extends AbstractController
{
    #[Route('/', name: "index", methods: 'GET')]
    public function index(){

    	$users = $this->getDoctrine()->getRepository(User::class)->findAll();

        return $this->json([
            'data' => $users
        ]);
    }
    #[Route('/{Id}', name: 'show', methods: 'GET')]
    public function show($Id){

        $user = $this->getDoctrine()->getRepository(User::class)->find($Id);

        return $this->json([
            'data' => $user
        ]);

    }

    #[Route('/', name: 'create', methods: 'POST')]
    public function create(Request $request){

    	$data = $request->request->all();

    	$user = new User();
    	$user->setName($data['name']);
    	$user->setEmail($data['email']);
    	$user->setCreatedAt(new \DateTime('now', new \DateTimezone('Europe/Lisbon')));
    	$user->setUpdatedAt(new \DateTime('now', new \DateTimezone('Europe/Lisbon')));

    	$doctrine = $this->getDoctrine()->getManager();

    	$doctrine->persist($user);
    	$doctrine->flush();

    	return $this->json([
    		'data' => 'Usuário Criado com sucesso!'
    	]);
    }

    #[Route('/{Id}', name: 'update', methods:['PUT', 'PATCH'])]

    public function update($Id, Request $request){

        $data = $request->request->all();

        $doctrine = $this->getDoctrine();

        $user = $this->getDoctrine()->getRepository(User::class)->find($Id);

        if ($request->request->has('name')) 
            $user->setName($data['name']);

        if($request->request->has('email'))
            $user->setEmail($data['email']);

        $user->setUpdatedAt(new \DateTime('now', new \DateTimezone('Europe/Lisbon')));

        $manager = $doctrine->getManager();

        $manager->flush();

        return $this->json([
            'data' => 'Usuário Atualizado com sucesso!'
        ]);

    }

    #[Route('/{Id}', name: 'delete', methods: 'DELETE')]
    public function delete($Id){

        $doctrine = $this->getDoctrine();

        $user = $doctrine->getRepository(User::class)->find($Id);

        $manager = $doctrine->getManager();
        $manager->remove($user);
        $manager->flush();

        return $this->json([
            'data' => 'Usuário Removido com sucesso!'
        ]);

    }


}
