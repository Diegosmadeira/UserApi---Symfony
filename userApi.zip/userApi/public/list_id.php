<?php
$id = ($_GET['id']);
$location = 'Location: http://127.0.0.1:8000/users/' . $id;

header($location);

?>